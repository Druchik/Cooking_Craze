﻿using UnityEngine;

/// <summary>
/// Точка спавна покупателя
/// </summary>
public class BuyerSpawnPoint : MonoBehaviour
{
    public Transform spawnPoint;
    public bool IsEmpty { get; set; } = true;
}
